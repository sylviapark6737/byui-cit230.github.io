function toggleHam() {
	document.getElementsByClassName("navigation")[0].classList.toggle("responsive");
}